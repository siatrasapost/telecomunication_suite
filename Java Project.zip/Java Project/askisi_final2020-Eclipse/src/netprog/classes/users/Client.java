package netprog.classes.users;


import java.sql.Timestamp;
import java.time.YearMonth;

public class Client extends Users {
	public String number;
	protected final String tin;

	/**
	 * Constructor
	 * @param attr_tin Personal TIN
	 * @param attr_number PhoneNumber object associated with this CLient object
	 */
    public Client(String attr_tin, String attr_number){
        super("Client");
        tin = attr_tin; //ΑΦΜ
        number = attr_number;
    }

    /**
     * Method that pays out a bill
     */
    public String payBill(){
        return "UPDATE bills SET paid = 1 WHERE number = ? AND date_issued LIKE ? ;";
    }

    /**
     * Method which shows the client's call history
     */
    public String viewCallHistory(){
        return "SELECT * FROM calls WHERE caller = ? AND time LIKE ?";
    }

    /**
     * Method that shows the bill for requested number and month
     */
    public String viewBill(){
        return "SELECT * FROM bills WHERE number = ? AND date_issued LIKE ?";

    }

    /**
     * Shows the full personal data of each client
     */
    public String viewPersonalData(){
    	return "SELECT * FROM clients WHERE username = ?;";
    }
    
    /**
     * Just a message showing that a Client has been created
     */
    @Deprecated
    public void Register() {
    	System.out.println("\nClient " + this.username + " has been created! ");
    
    }
    
    /**
     * Just a message showing that a Client has Logged in
     */
    @Deprecated
    public void Login() {
    	System.out.println("\nClient " +  this.username + " has successfully logged in ");
    	
    }
    
    /**
     * Just a message showing that a Client has Logged out
     */
    @Deprecated
    public void Logout() {
    	System.out.println("\nClient " +  this.username + " has successfully logged out ");

    	
    }
    
    
}

