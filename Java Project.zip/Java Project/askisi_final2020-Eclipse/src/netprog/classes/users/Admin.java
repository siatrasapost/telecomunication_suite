package netprog.classes.users;

public class Admin extends Users{
	
	
	/**
	 * Constructor
	 */
	
    public Admin(){
        super("Admin");
    }

    /**
     * Creates a new Seller object and then return it
     * @return Seller object
     */
    public final String addSeller(){ return "INSERT INTO sellers VALUES (?,?,?,?)";}
    
    /**
     * Edits the attributes of Seller object
     */

    public final String editSeller() {
        return "UPDATE sellers SET username = ?, name = ?, surname = ? WHERE username = ?;";
    }
    
    /**
     * Deletes the specified Seller
     */

    public  final String deleteSeller(){ return "DELETE FROM sellers WHERE username = ?;";}
    
    /**
     * Creates a new Program object and then returns it
     * @return Program object
     */
    public final String addPrograms(){ return "INSERT INTO programs VALUES (?,?,?,?,?,?)";}


    /**
     * Edits the attributes of a specified Program object
     */

    public final String editPrograms(){
        return "UPDATE programs SET program_name = ?, fixed_charge = ?, minutes_charge = ?, messages_charge = ?, minutes = ?, messages = ? WHERE program_name = ?;";
    }
    
    /**
     * Deletes a specified Program
     */

    public final String deletePrograms(){
        return "DELETE FROM programs WHERE program_name = ?;";
    }

    public final String updateNumbersDelete(){
        return "UPDATE numbers SET program_name = 'Basic500' WHERE program_name = ?;";
    }

    public final String showProgramInfo(){
        return "SELECT * FROM programs WHERE program_name = ?;";
    }

    public final String showSellerInfo(){
        return "SELECT * FROM sellers WHERE username = ?;";
    }
    
    /**
     * Just a message showing that an Admin has been created
     */
    @Deprecated
    public void Register() {
    	System.out.println("\nAdmin " + this.username + " has been created! ");
    	
    }
    
    /**
     * Just a message showing that an Admin has Logged in
     */
    @Deprecated
    public void Login() {
    	System.out.println("\nAdmin " +  this.username + " has successfully logged in ");
    	
    }
    
    /**
     * Just a message showing that an Admin has Logged out
     */
    @Deprecated
    public void Logout() {
    	System.out.println("\nAdmin " +  this.username + " has successfully logged out ");

    	
    }
}


