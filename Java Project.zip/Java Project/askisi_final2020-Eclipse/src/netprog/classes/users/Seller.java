package netprog.classes.users;

import java.util.Scanner;


public class Seller extends Users {
    
	/**
	 * Constructor
	 */
	public Seller(){
        super("Seller");    
    }

	/**
	 * Function used as a query in Prepared Statement
	 * @return the SQL query which adds a new Client in Database
	 */
    public final String addClient() {
    	return "INSERT INTO clients VALUES (?,?,?,?,?,?)";
    }

	/**
	 * Function used as a query in Prepared Statement
	 * @return the SQL query which associates a client's number with a telecommunications program
	 */
	public final String clientProgram(){
    	return "INSERT INTO numbers VALUES (?, ?)";
	}

	/**
	 * Function used as a query in Prepared Statement
	 * @return the SQL query which shows some information about the Client
	 */
	public final String showClientPartially(){
		return "SELECT username, name, surname FROM clients WHERE phone_number = ?;";
	}

	/**
	 * Method which shows client's info
	 */
	public final String showClientInfo(){
		return  "SELECT * FROM clients WHERE phone_number = ?";
	}

	/**
	 * Function used as a query in Prepared Statement
	 * @return the SQL query which shows all telecommunications programs
	 */
	public final String showPrograms(){
		return "SELECT * FROM programs;";
	}


	/**
	 * Method that shows the requested program, based on client's phone number
	 */
	public final String getClientProgram(){
		return "SELECT * FROM programs WHERE program_name = (SELECT program_name FROM numbers WHERE phone_number = ? );";
	}

    /**
     * Edits the attributes of the specified Client object
     */
    public final String editClient(){
		return "UPDATE clients SET username = ?, name = ?, surname = ?, tin = ? WHERE phone_number = ?";
    }
    
    /**
     * Deletes a Clients
     */
    public final String deleteFromClients(){
		return "DELETE FROM clients WHERE phone_number = ?;";
	}

	/**
	 * Mehtod that deletes client's info from numbers table
	 */
	public final String deleteFromNumbers() {
    	return "DELETE FROM numbers WHERE phone_number = ?;";
	}

	/**
	 * Mehtod that deletes client's info from calls table
	 */
	public final String deleteFromCalls() {
    	return "DELETE FROM calls WHERE caller = ?;";
	}

	/**
	 * Mehtod that deletes client's info from bills table
	 */
	public final String deleteFromBills() {
    	return "DELETE FROM bills WHERE number = ?;";
	}

	/**
	 * Method which inserts a new bill into bills table
	 */
    public final String billIssuance() {
		return "INSERT INTO bills VALUES (?, ?, ?, ?, ?, ?, ?);";
    }

	/**
	 * Method that inserts calls into calls table
	 */
	public String insertCalls(){
    	return "INSERT INTO calls VALUES (?, ?, ?, ?, ?);";
	}
    
    /**
     * Just a message showing that a Seller has been created
     */
    @Deprecated
    public void Register() {
    	System.out.println("\nSeller " + this.username + " has been created! ");
    	
    }
    
    /**
     * Just a message showing that a Seller has Logged in
     */

    @Deprecated
    public void Login() {
    	System.out.println("\nSeller " +  this.username + " has successfully logged in ");
    	
    }
    
    /**
     * Just a message showing that a Seller has Logged out
     */
    @Deprecated
    public void Logout() {
    	System.out.println("\nSeller " +  this.username + " has successfully logged out ");

    	
    }
}
