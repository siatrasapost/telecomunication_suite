package netprog.classes.users;


import javax.servlet.http.HttpSession;

public abstract class Users {
	protected String username, name, surname, role;
    public static int usersCounter = 0;

    
    /**
     * Constructor that counts the total amount of users and specifies their role
     * @param attr_role Role specifies each unique user
     */
    public Users(String attr_role){
        usersCounter++;
        this.setRole(attr_role);
    }

    /*
     * Abstract methods which are being declared in Admin, Client and the Seller classes
     */
    
    public abstract void Register();
    public abstract void Login();
    public abstract void Logout();

    
    
    /**
     * Username getter
     * @return User's username
     */
    
    public String getUsername(){return username;}
    
    /**
     * Name getter
     * @return User's name
     */
    
    public String getName(){return name;}
    
    /**
     * Surname getter
     * @return User's surname
     */
    
    public String getSurname(){return surname;}
    
    /**
     * Role getter
     * @return User's Role
     */
    
    public String getRole(){return role;}

    /**
     * Username setter
     * @param attr_username Username parameter to be set
     */
    
    public void setUsername(String attr_username){
        username = attr_username;
    }

    /**
     * Name setter
     * @param attr_name Name parameter to be set
     */
    
    public void setName(String attr_name){
        name = attr_name;
    }
    
    /**
     * Surname setter
     * @param attr_surname Surname parameter to be set
     */
    
    public void setSurname(String attr_surname){
        surname = attr_surname;
    }

    /**
     * Role setter
     * @param attr_role Role parameter to be set
     */
    
    public void setRole(String attr_role){
        role = attr_role;
    }
    


}
