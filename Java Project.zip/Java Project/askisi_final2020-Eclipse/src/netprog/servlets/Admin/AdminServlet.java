package netprog.servlets.Admin;

import netprog.classes.users.Admin;
import netprog.classes.users.Client;
import netprog.classes.users.Seller;
import netprog.servlets.Encryption;
import netprog.servlets.LoginServlet;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

@WebServlet("/adminservlet")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static Admin admin = new Admin();

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    public static Admin getAdmin(String name, String surname){
        admin.setName(name);
        admin.setSurname(surname);
        return admin;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        String username = request.getParameter("new_user");
        String password = request.getParameter("new_pass");
        String name = request.getParameter("new_name");
        String surname = request.getParameter("new_surname");
        try {
            Connection con = datasource.getConnection();

            PreparedStatement preparedStatement = con.prepareStatement(((Admin) LoginServlet.user).addSeller());
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, Encryption.getHashMD5(password));
            preparedStatement.setString(3, name);
            preparedStatement.setString(4, surname);

            preparedStatement.executeUpdate();
            request.getRequestDispatcher("/admin.jsp").forward(request, response);

            preparedStatement.close();
            con.close();
        } catch(Exception e) {
            out.println("Database connection problem");
            //out.println("<br>");
            //out.println(e.getLocalizedMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
