package netprog.servlets;

import netprog.classes.users.Admin;
import netprog.classes.users.Client;
import netprog.classes.users.Seller;
import netprog.classes.users.Users;
import netprog.servlets.Admin.AdminServlet;
import netprog.servlets.Client.ClientServlet;
import netprog.servlets.Seller.SellerServlet;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/main")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public static HttpSession session = null;
    public static Users user = null;

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException {
        try{
            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        }
        catch (Exception e){
            throw new ServletException(e.toString());
        }
    }

    /**
     * Automatic constructor (created by IntelliJ)
     */
    public LoginServlet(){
        super();
    }

    /**
     * Function to be executed when submitting a form, using POST method
     * @param req
     * @param res
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        res.setCharacterEncoding("UTF-8");

        PrintWriter out = res.getWriter();
        out.println("<html>");
        out.println("<head><title>Σύνδεση | Πλατφόρμα πρόσβασης σε ΒΔ</title>" +
                "<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\"></head>");
        out.println("<body>");

        try{
            Connection con = datasource.getConnection();
            Statement stmt = con.createStatement();

            String username = req.getParameter("username");
            String password = req.getParameter("password");
            String attribute = req.getParameter("attribute");

            String hashed = Encryption.getHashMD5(password, "uyfhvu43");

            ResultSet rs = stmt.executeQuery("SELECT * FROM " + attribute +
                    " WHERE username='" + username + "' AND password='" + hashed +"';");

            boolean found = false;
            while (rs.next()){
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String URL = "";

                session = req.getSession(true);
                switch (attribute){
                    case "sellers":
                        user = (Seller)session.getAttribute("seller");
                        if (user == null){
                            user = SellerServlet.getSeller(name, surname);
                            session.setAttribute("seller", user);
                        }
                        URL = "/seller.jsp";
                        break;
                    case "admins":
                        user = (Admin)session.getAttribute("admin");
                        if (user == null){
                            user = AdminServlet.getAdmin(name, surname);
                            session.setAttribute("admin", user);
                        }
                        URL = "/admin.jsp";
                        break;
                    case "clients":
                        user = (Client)session.getAttribute("client");
                        if (user == null){
                            user = ClientServlet.getClient(name, surname, username, rs.getString("phone_number"));
                            session.setAttribute("client", user);
                        }
                        URL = "/client.jsp";
                }
                req.getRequestDispatcher(URL).forward(req,res);

                found = true;
            }

            rs.close();
            con.close();

            if (!found){
                out.println("<h2 style='text-align: center'>Λανθασμένο Όνομα Χρήστη ή/και Κωδικός Πρόσβασης</h2>");
                out.println("<br>");
                out.println("<h3 style='text-align: center'><a href='index.html'>Επιστροφή στην σελίδα σύνδεσης</a></h3>");
            }
        }
        catch (Exception e){
            out.println("Database connection problem");
            out.println("<br>");
            out.println(e.getLocalizedMessage());
        }
        finally {
            out.println("</body>");
            out.println("</html>");
        }
    }
}
