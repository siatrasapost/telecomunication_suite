package netprog.servlets;

import netprog.classes.users.Admin;
import netprog.classes.users.Client;
import netprog.classes.users.Seller;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Locale;

@WebServlet("/logoutservlet")
public class LogoutServlet extends HttpServlet {
    private DataSource datasource = null;
    public HttpSession session = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        try {
            session = request.getSession(false);
            Seller value = (Seller)session.getAttribute("seller");
            Client value2 = (Client)session.getAttribute("client");
            Admin value3 = (Admin)session.getAttribute("admin");
            if (value != null | value2 != null | value3 != null) {
//                response.setHeader("Cache-Control","no-cache");
//                response.setDateHeader("Expires", 0);
//                response.setHeader("Pragma","no-cache");
                response.setHeader("Cache-Control","no-cache");
                response.setDateHeader("Expires", 0);
                response.setHeader("Pragma","no-cache");
                session.removeAttribute("seller");
                session.removeAttribute("client");
                session.removeAttribute("admin");
                LoginServlet.session = null;
                session.invalidate();
                response.sendRedirect("disconnect.html");

                //LoginServlet.session.invalidate();
            }
            else {
                out.println("Your session has expired!");
                out.println("You will be redirected to Log In Screen...");
                response.sendRedirect("index.html");
            }
        } catch(Exception e) {
            out.println("Database connection problem");
            out.println("<br>");
            out.println(e.getLocalizedMessage());
        }
    }
}
