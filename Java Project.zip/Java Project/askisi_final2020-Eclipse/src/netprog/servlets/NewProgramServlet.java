package netprog.servlets;

import netprog.classes.users.Admin;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/newprogramservlet")
public class NewProgramServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        if (LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                String program_name = request.getParameter("pr_name");
                int fixed_charge = Integer.parseInt(request.getParameter("fixed_charge"));
                double minutes_charge = Double.parseDouble(request.getParameter("min_charge"));
                double messages_charge = Double.parseDouble(request.getParameter("mes_charge"));
                int minutes = Integer.parseInt(request.getParameter("minutes"));
                int messages = Integer.parseInt(request.getParameter("messages"));

                PreparedStatement preparedStatement = con.prepareStatement(((Admin) LoginServlet.user).addPrograms());
                preparedStatement.setString(1, program_name);
                preparedStatement.setInt(2, fixed_charge);
                preparedStatement.setDouble(3, minutes_charge);
                preparedStatement.setDouble(4, messages_charge);
                preparedStatement.setInt(5, minutes);
                preparedStatement.setInt(6, messages);

                preparedStatement.executeUpdate();
                request.getRequestDispatcher("/admin.jsp").forward(request, response);

                preparedStatement.close();
                con.close();
            } catch (Exception e) {
                out.println("Database connection problem");
                //out.println("<br>");
                //out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session Timeout!");
    }
}

