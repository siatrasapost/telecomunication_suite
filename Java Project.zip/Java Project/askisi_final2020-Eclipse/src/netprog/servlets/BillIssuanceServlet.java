package netprog.servlets;

import netprog.classes.users.Admin;
import netprog.classes.users.Client;
import netprog.classes.users.Seller;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDate;

@WebServlet("/billissuanceservlet")
public class BillIssuanceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Seller seller;
    public String joined = "";
    public String callto = "";

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {
            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();
                String phone = request.getParameter("client_phone");
                PreparedStatement showClient = con.prepareStatement(((Seller) LoginServlet.user).showClientPartially());
                showClient.setString(1, phone);

                ResultSet rs = showClient.executeQuery();

                String username = null;
                String name = null;
                String surname = null;
                boolean found = false;
                while (rs.next()) {
                    username = rs.getString("username");
                    name = rs.getString("name");
                    surname = rs.getString("surname");
                    found = true;
                }
                request.setAttribute("username", username);
                request.setAttribute("name", name);
                request.setAttribute("surname", surname);
                request.setAttribute("phone", phone);

                rs.close();
                showClient.close();
                con.close();

                request.getRequestDispatcher("/bill_issuance.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                //out.println("<br>");
                //out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session Timeout!");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        if (LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                int calls_number = Integer.parseInt(request.getParameter("i"));
                String number = request.getParameter("phone");

                int mes_number = Integer.parseInt(request.getParameter("mes_quantity"));
                int total_duration = 0;

                for (int i = 0; i < calls_number; i++) {
                    callto = request.getParameter("callto" + (i + 1));
                    joined = request.getParameter("date" + (i + 1)) + " " + request.getParameter("time" + (i + 1));
                    Timestamp datetime = Timestamp.valueOf(joined);
                    int min_dur = Integer.parseInt(request.getParameter("min_dur" + (i + 1)));
                    double sec_dur = Double.parseDouble(request.getParameter("sec_dur" + (i + 1)));

                    total_duration += min_dur;
                    total_duration += Math.ceil(sec_dur / 60.0);

                    PreparedStatement ps = con.prepareStatement(((Seller) LoginServlet.user).insertCalls());
                    ps.setString(1, number);
                    ps.setString(2, callto);
                    ps.setTimestamp(3, datetime);
                    ps.setInt(4, min_dur);
                    ps.setInt(5, (int) sec_dur);

                    ps.executeUpdate();

                    ps.close();
                }

                double total_cost = 0.0;

                PreparedStatement clientprogram = con.prepareStatement(((Seller) LoginServlet.user).getClientProgram());

                clientprogram.setString(1, number);

                ResultSet resultSet = clientprogram.executeQuery();

                int fixed_charge = 0;
                double minutes_charge = 0.0;
                double message_charge = 0.0;
                int minutes = 0;
                int messages = 0;
                while (resultSet.next()) {
                    fixed_charge = resultSet.getInt("fixed_charge");
                    minutes_charge = resultSet.getDouble("minutes_charge");
                    message_charge = resultSet.getDouble("messages_charge");
                    minutes = resultSet.getInt("minutes");
                    messages = resultSet.getInt("messages");
                }

                resultSet.close();
                clientprogram.close();

                if (minutes >= total_duration && messages >= mes_number) {
                    total_cost = fixed_charge;
                } else {
                    double call_cost, message_cost = 0.0;
                    if (minutes < total_duration && messages < mes_number) {
                        call_cost = (total_duration - minutes) * minutes_charge;
                        message_cost = (mes_number - messages) * message_charge;
                        total_cost = call_cost + message_cost + fixed_charge;
                    } else if (minutes < total_duration) {
                        call_cost = (total_duration - minutes) * minutes_charge;
                        total_cost = call_cost + fixed_charge;
                    } else {
                        message_cost = (mes_number - messages) * message_charge;
                        total_cost = message_cost + fixed_charge;
                    }
                }

                PreparedStatement billissuance = con.prepareStatement(((Seller) LoginServlet.user).billIssuance());
                billissuance.setString(1, number);
                billissuance.setString(2, LocalDate.now().toString());
                billissuance.setInt(3, calls_number);
                billissuance.setInt(4, mes_number);
                billissuance.setInt(5, total_duration);
                billissuance.setDouble(6, total_cost);
                billissuance.setByte(7, (byte) 0);

                billissuance.executeUpdate();

                billissuance.close();

                request.getRequestDispatcher("/seller.jsp").forward(request, response);
                con.close();
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
                out.println("<br>");
                out.println(callto);
                out.println(joined);
            }
        }
        else
            out.println("Session Timeout!");
    }
}
