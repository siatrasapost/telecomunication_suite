package netprog.servlets;

import netprog.classes.users.Admin;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/editprogramservlet")
public class EditProgramServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session != null) {
            try {
                Connection con = datasource.getConnection();

                String program_name = request.getParameter("original_name");


                if (request.getParameter("choices").equals("delete")){
                    PreparedStatement ps = con.prepareStatement(((Admin)LoginServlet.user).updateNumbersDelete());
                    ps.setString(1, program_name);
                    ps.executeUpdate();
                    ps.close();

                    PreparedStatement ps1 = con.prepareStatement(((Admin)LoginServlet.user).deletePrograms());
                    ps1.setString(1, program_name);
                    ps1.executeUpdate();
                    ps1.close();
                }
                else if (request.getParameter("choices").equals("update")){
                    PreparedStatement preparedStatement = con.prepareStatement(((Admin)LoginServlet.user).editPrograms());
                    preparedStatement.setString(1, request.getParameter("pr_name"));
                    preparedStatement.setInt(2, Integer.parseInt(request.getParameter("fixed_charge")));
                    preparedStatement.setDouble(3, Double.parseDouble(request.getParameter("min_charge")));
                    preparedStatement.setDouble(4, Double.parseDouble(request.getParameter("mes_charge")));
                    preparedStatement.setInt(5, Integer.parseInt(request.getParameter("minutes")));
                    preparedStatement.setInt(6, Integer.parseInt(request.getParameter("messages")));
                    preparedStatement.setString(7, program_name);

                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                }

                con.close();

                request.getRequestDispatcher("/admin.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session timeout!");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session != null) {
            try {
                Connection con = datasource.getConnection();

                String program_name = request.getParameter("program_name");

                PreparedStatement ps = con.prepareStatement(((Admin)LoginServlet.user).showProgramInfo());
                ps.setString(1, program_name);

                ResultSet rs = ps.executeQuery();

                String name = "";
                int fixed_charge = 0;
                double min_charge = 0.0;
                double mes_charge = 0.0;
                int minutes = 0;
                int messages = 0;
                while(rs.next()){
                    name = rs.getString("program_name");
                    fixed_charge = rs.getInt("fixed_charge");
                    min_charge = rs.getDouble("minutes_charge");
                    mes_charge = rs.getDouble("messages_charge");
                    minutes = rs.getInt("minutes");
                    messages = rs.getInt("messages");
                }

                request.setAttribute("pr_name", name);
                request.setAttribute("fixed_charge", fixed_charge);
                request.setAttribute("min_charge", min_charge);
                request.setAttribute("mes_charge", mes_charge);
                request.setAttribute("minutes", minutes);
                request.setAttribute("messages", messages);

                rs.close();
                ps.close();
                con.close();

                request.getRequestDispatcher("/edit_program.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session timeout!");
    }
}
