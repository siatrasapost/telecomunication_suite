package netprog.servlets;

import netprog.classes.users.Client;
import netprog.classes.users.Seller;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.YearMonth;

@WebServlet("/callservlet")
public class CallServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataSource datasource = null;

    private String URL = "";

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if(LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                PreparedStatement showCalls = con.prepareStatement(((Client) LoginServlet.user).viewCallHistory());
                showCalls.setString(1, ((Client)LoginServlet.user).number);
                showCalls.setString(2, request.getParameter("callformonth") + "-%");
                ResultSet rs = showCalls.executeQuery();

                int i = 0;
                String htmlRow = "";
                while (rs.next()) {
                    i++;

                    String caller = rs.getString("caller");
                    String number = rs.getString("number");
                    Timestamp time = rs.getTimestamp("time");
                    String min_duration = rs.getString("minutes_duration");
                    String sec_duration = rs.getString("seconds_duration");

                    htmlRow = createHTMLRow(caller, number, time, min_duration, sec_duration);
                    request.setAttribute("callrow" + i, htmlRow);

                }
                request.setAttribute("time", request.getParameter("callformonth"));
                request.setAttribute("numberofcalls", i);

                showCalls.close();
                rs.close();
                con.close();

                if (request.getParameter("bill")!= null && request.getParameter("bill").equals("bill")){
                    Connection con1 = datasource.getConnection();

                    PreparedStatement showBill = con1.prepareStatement(((Client)LoginServlet.user).viewBill());
                    showBill.setString(1, ((Client)LoginServlet.user).number);
                    showBill.setString(2, request.getParameter("callformonth") + "-%");
                    ResultSet rs1 = showBill.executeQuery();

                    String billrow = "";
                    while (rs1.next()){
                        String number_of_client=rs1.getString("number");
                        String date_issued = rs1.getString("date_issued");
                        int calls_number = rs1.getInt("calls_number");
                        int messages_number = rs1.getInt("messages_number");
                        int total_dur = rs1.getInt("total_duration");
                        double total_cost = rs1.getDouble("total_cost");
                        byte paid = rs1.getByte("paid");

                        billrow = createHTMLRow(number_of_client, date_issued, calls_number, messages_number, total_dur);
                        request.setAttribute("billrow", billrow);
                        request.setAttribute("total_cost", total_cost);
                        request.setAttribute("paid", paid);
                    }

                    showBill.close();
                    rs1.close();
                    con1.close();

                    URL = "/showbill.jsp";
                }
                else {
                    URL = "/showcalls.jsp";
                }
//                request.setAttribute("session_info", ((Seller)LoginServlet.session.getAttribute("seller")).getName() + " "
//                        + ((Seller)LoginServlet.session.getAttribute("seller")).getSurname());
                request.getRequestDispatcher(URL).forward(request, response);

            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else {
            out.println("Session Timeout");
        }
    }

    /**
     * This function creates a simple HTML table row, which includes information about telecommunications program
     * @param caller Caller
     * @param number Number of the call
     * @param timestamp time
     * @param min_dur Call's duration (minutes part)
     * @param sec_dur Call's duration (seconds part)
     * @return the complete row
     */
    private String createHTMLRow(String caller, String number, Timestamp timestamp, String min_dur, String sec_dur) {
        String row = "<tr>";
        row  += "<td>" + caller + "</td>";
        row  += "<td>" + number + "</td>";
        row  += "<td>" + timestamp + "</td>";
        row  += "<td>" + min_dur + "</td>";
        row  += "<td>" + sec_dur + "</td>";
        row += "</tr>";
        return row;

    }

    private String createHTMLRow(String n, String d, int calls_n, int mes_n, int total_dur) {
        String row = "<tr>";
        row  += "<td>" + n + "</td>";
        row  += "<td>" + d + "</td>";
        row  += "<td>" + calls_n + "</td>";
        row  += "<td>" + mes_n + "</td>";
        row  += "<td>" + total_dur + "</td>";
        row += "</tr>";
        return row;

    }
}
