package netprog.servlets;

import netprog.classes.users.Admin;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/editsellerservlet")
public class EditSellerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session != null) {
            try {
                Connection con = datasource.getConnection();

                String username = request.getParameter("original_user");


                if (request.getParameter("choices").equals("delete")){
                    PreparedStatement ps = con.prepareStatement(((Admin)LoginServlet.user).deleteSeller());
                    ps.setString(1, username);
                    ps.executeUpdate();
                    ps.close();

                }
                else if (request.getParameter("choices").equals("update")){
                    PreparedStatement preparedStatement = con.prepareStatement(((Admin)LoginServlet.user).editSeller());
                    preparedStatement.setString(1, request.getParameter("user"));
                    preparedStatement.setString(2, request.getParameter("name"));
                    preparedStatement.setString(3, request.getParameter("surname"));
                    preparedStatement.setString(4, username);

                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                }

                con.close();

                request.getRequestDispatcher("/admin.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session timeout!");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session != null) {
            try {
                Connection con = datasource.getConnection();

                String username = request.getParameter("username");

                PreparedStatement ps = con.prepareStatement(((Admin)LoginServlet.user).showSellerInfo());
                ps.setString(1, username);

                ResultSet rs = ps.executeQuery();

                String user = "";
                String name = "";
                String surname = "";
                while(rs.next()){
                    user = rs.getString("username");
                    name = rs.getString("name");
                    surname = rs.getString("surname");
                }

                request.setAttribute("username", user);
                request.setAttribute("name", name);
                request.setAttribute("surname", surname);

                rs.close();
                ps.close();
                con.close();

                request.getRequestDispatcher("/edit_seller.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session timeout!");
    }
}
