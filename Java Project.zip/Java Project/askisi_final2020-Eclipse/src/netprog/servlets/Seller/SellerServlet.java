package netprog.servlets.Seller;

import netprog.classes.users.Admin;
import netprog.classes.users.Seller;
import netprog.classes.users.Users;
import netprog.servlets.Encryption;
import netprog.servlets.LoginServlet;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/sellerservlet")
public class SellerServlet extends HttpServlet{
    private static final long serialVersionUID = 1L;

    private static Seller seller = new Seller();

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    /**
     * Function to be executed when submitting a form, using GET method
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if(LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                PreparedStatement showPrograms = con.prepareStatement(((Seller) LoginServlet.user).showPrograms());
                ResultSet rs = showPrograms.executeQuery();
                int i = 0;
                String htmlRow = "";
                while (rs.next()) {
                    i++;

                    String pr_name = rs.getString("program_name");
                    int fixed_charge = rs.getInt("fixed_charge");
                    double minutes_charge = rs.getDouble("minutes_charge");
                    double messages_charge = rs.getDouble("messages_charge");
                    int minutes = rs.getInt("minutes");
                    int messages = rs.getInt("messages");
                    htmlRow = createHTMLRow(pr_name, fixed_charge, minutes_charge, messages_charge, minutes, messages);
                    request.setAttribute("htmlrow" + i, htmlRow);

                }
                request.setAttribute("numberofrows", i);
//                request.setAttribute("session_info", ((Seller)LoginServlet.session.getAttribute("seller")).getName() + " "
//                        + ((Seller)LoginServlet.session.getAttribute("seller")).getSurname());
                request.getRequestDispatcher("/view_prog.jsp").forward(request, response);

                showPrograms.close();
                rs.close();

                con.close();
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else {
            out.println("Session Timeout");
        }
    }

    /**
     * This function creates a simple HTML table row, which includes information about telecommunications program
     * @param prog_name Program's name
     * @param f_charge Fixed charge
     * @param min_charge charge per minute (except contract charge)
     * @param mes_charge charge per message (except contract charge)
     * @param min free minutes
     * @param mes free messages
     * @return the complete row
     */
    private String createHTMLRow(String prog_name, int f_charge, double min_charge, double mes_charge, int min, int mes) {
        String row = "<tr>";
        row  += "<td>" + prog_name + "</td>";
        row  += "<td>" + f_charge + "</td>";
        row  += "<td>" + min_charge + "</td>";
        row  += "<td>" + mes_charge + "</td>";
        row  += "<td>" + min + "</td>";
        row  += "<td>" + mes + "</td>";
        row +="</tr>";
        return row;

    }

    /**
     * Function to be executed when submitting a form, using POST method
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        if(LoginServlet.session!=null) {
            String username = request.getParameter("new_user");
            String password = request.getParameter("new_pass");
            String name = request.getParameter("new_name");
            String surname = request.getParameter("new_surname");
            String tin = request.getParameter("tin");
            String phone_number = request.getParameter("phone");
            try {
                Connection con = datasource.getConnection();
                Statement stmt = con.createStatement();

                PreparedStatement preparedStatement = con.prepareStatement(((Seller) LoginServlet.user).addClient());
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, Encryption.getHashMD5(password));
                preparedStatement.setString(3, name);
                preparedStatement.setString(4, surname);
                preparedStatement.setString(5, tin);
                preparedStatement.setString(6, phone_number);

                preparedStatement.executeUpdate();
                request.getRequestDispatcher("/cust_program.jsp").forward(request, response);

                preparedStatement.close();
                con.close();
            } catch (Exception e) {
                out.println("Database connection problem");
                //out.println("<br>");
                //out.println(e.getLocalizedMessage());
            }
        }
        else{
            response.sendRedirect("seller.jsp");
        }
    }

    /**
     * Getter method
     * @return a static Seller object
     */
    public static Seller getSeller(String name, String surname){
        seller.setName(name);
        seller.setSurname(surname);
        return seller;
    }
}
