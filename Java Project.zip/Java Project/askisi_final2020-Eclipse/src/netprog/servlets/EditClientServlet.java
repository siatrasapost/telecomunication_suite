package netprog.servlets;

import netprog.classes.users.Seller;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/editclientservlet")
public class EditClientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {
            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session != null) {
            try {
                Connection con = datasource.getConnection();

                String phone = request.getParameter("client_phone");


                if (request.getParameter("choices").equals("delete")){
                    PreparedStatement ps = con.prepareStatement(((Seller)LoginServlet.user).deleteFromClients());
                    ps.setString(1, phone);
                    ps.executeUpdate();
                    ps.close();

                    PreparedStatement ps1 = con.prepareStatement(((Seller)LoginServlet.user).deleteFromNumbers());
                    ps1.setString(1, phone);
                    ps1.executeUpdate();
                    ps1.close();

                    PreparedStatement ps2 = con.prepareStatement(((Seller)LoginServlet.user).deleteFromCalls());
                    ps2.setString(1, phone);
                    ps2.executeUpdate();
                    ps2.close();

                    PreparedStatement ps3 = con.prepareStatement(((Seller)LoginServlet.user).deleteFromBills());
                    ps3.setString(1, phone);
                    ps3.executeUpdate();
                    ps3.close();
                }
                else if (request.getParameter("choices").equals("update")){
                    PreparedStatement preparedStatement = con.prepareStatement(((Seller)LoginServlet.user).editClient());
                    preparedStatement.setString(1, request.getParameter("user"));
                    preparedStatement.setString(2, request.getParameter("name"));
                    preparedStatement.setString(3, request.getParameter("surname"));
                    preparedStatement.setString(4, request.getParameter("tin"));
                    preparedStatement.setString(5, phone);

                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                }

                con.close();

                request.getRequestDispatcher("/seller.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session timeout!");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if (LoginServlet.session != null) {
            try {
                Connection con = datasource.getConnection();
                String phone = request.getParameter("phone");
                PreparedStatement showClient = con.prepareStatement(((Seller) LoginServlet.user).showClientInfo());
                showClient.setString(1, phone);

                ResultSet rs = showClient.executeQuery();

                String username = null;
                String password = null;
                String name = null;
                String surname = null;
                String tin = null;
                while (rs.next()) {
                    username = rs.getString("username");
                    password = Encryption.getHashMD5(rs.getString("password"));
                    name = rs.getString("name");
                    surname = rs.getString("surname");
                    tin = rs.getString("tin");
                }
                request.setAttribute("username", username);
                request.setAttribute("password", password);
                request.setAttribute("name", name);
                request.setAttribute("surname", surname);
                request.setAttribute("tin", tin);
                request.setAttribute("phone", phone);

                rs.close();
                showClient.close();
                con.close();

                request.getRequestDispatcher("/editclient.jsp").forward(request, response);
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
                out.println(request.getParameter("choices"));
            }
        }
        else
            out.println("Session timeout!");
    }
}
