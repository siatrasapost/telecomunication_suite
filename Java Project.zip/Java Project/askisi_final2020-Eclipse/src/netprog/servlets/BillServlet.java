package netprog.servlets;

import netprog.classes.users.Client;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

@WebServlet("/billservlet")
public class BillServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if(LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                PreparedStatement payment = con.prepareStatement(((Client) LoginServlet.user).payBill());

                payment.setString(1, ((Client) LoginServlet.user).number);
                payment.setString(2, request.getParameter("date_issued") + "%");
                int i = payment.executeUpdate();

                response.sendRedirect("client.jsp");

                payment.close();

                con.close();
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else {
            out.println("Session Timeout");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if(LoginServlet.session!=null) {
            try {
                Connection con1 = datasource.getConnection();

                PreparedStatement showBill = con1.prepareStatement(((Client) LoginServlet.user).viewBill());
                showBill.setString(1, ((Client)LoginServlet.user).number);
                showBill.setString(2, request.getParameter("callformonth") + "-%");
                ResultSet rs1 = showBill.executeQuery();

                String billrow = "";
                while (rs1.next()) {
                    String number_of_client = rs1.getString("number");
                    String date_issued = rs1.getString("date_issued");
                    int calls_number = rs1.getInt("calls_number");
                    int messages_number = rs1.getInt("messages_number");
                    int total_dur = rs1.getInt("total_duration");
                    double total_cost = rs1.getDouble("total_cost");
                    byte paid = rs1.getByte("paid");

                    billrow = createHTMLRow(number_of_client, date_issued, calls_number, messages_number, total_dur);
                    request.setAttribute("billrow", billrow);
                    request.setAttribute("total_cost", total_cost);
                    request.setAttribute("paid", paid);
                }
                request.setAttribute("month", request.getParameter("callformonth"));

                request.getRequestDispatcher("/paybill.jsp").forward(request, response);

                showBill.close();
                rs1.close();
                con1.close();
            }
            catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else{
            out.println("Session Timeout");
        }
    }

    private String createHTMLRow(String n, String d, int calls_n, int mes_n, int total_dur) {
        String row = "<tr>";
        row  += "<td>" + n + "</td>";
        row  += "<td>" + d + "</td>";
        row  += "<td>" + calls_n + "</td>";
        row  += "<td>" + mes_n + "</td>";
        row  += "<td>" + total_dur + "</td>";
        row += "</tr>";
        return row;

    }
}
