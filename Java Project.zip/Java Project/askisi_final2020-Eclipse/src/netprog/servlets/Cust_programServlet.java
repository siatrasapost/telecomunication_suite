package netprog.servlets;

import netprog.classes.users.Seller;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/custprogservlet")
public class Cust_programServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }

    /**
     * Function to be executed when submitting a form, using POST method
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        if (LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();
                Statement stmt = con.createStatement();

                PreparedStatement insertClientProgram = con.prepareStatement(((Seller) LoginServlet.user).clientProgram());

                insertClientProgram.setString(1, request.getParameter("number"));
                insertClientProgram.setString(2, request.getParameter("rad_htmlrow"));

                insertClientProgram.executeUpdate();
                request.getRequestDispatcher("/seller.jsp").forward(request, response);

                insertClientProgram.close();
                con.close();

            } catch (Exception e) {
                out.println("Database connection problem");
                //out.println("<br>");
                //out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session Timeout!");
    }

    /**
     * This function creates a simple HTML table row, which includes information about telecommunications program
     * @param prog_name Program's name
     * @param f_charge Fixed charge
     * @param min_charge charge per minute (except contract charge)
     * @param mes_charge charge per message (except contract charge)
     * @param min free minutes
     * @param mes free messages
     * @return the complete row, without row-closing character (</tr>)
     */
    private String createHTMLRow(String prog_name, int f_charge, double min_charge, double mes_charge, int min, int mes) {
        String row = "<tr>";
        row  += "<td>" + prog_name + "</td>";
        row  += "<td>" + f_charge + "</td>";
        row  += "<td>" + min_charge + "</td>";
        row  += "<td>" + mes_charge + "</td>";
        row  += "<td>" + min + "</td>";
        row  += "<td>" + mes + "</td>";
        return row;
    }

    /**
     * Function to be executed when submitting a form, using GET method
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        if (LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                String phone = request.getParameter("phone");

                PreparedStatement showClient = con.prepareStatement(((Seller) LoginServlet.user).showClientPartially());
                showClient.setString(1, phone);
                ResultSet rs = showClient.executeQuery();

                String username = null;
                String name = null;
                String surname = null;

                boolean found = false;
                while (rs.next()) {
                    username = rs.getString("username");
                    name = rs.getString("name");
                    surname = rs.getString("surname");

                    found = true;
                }

                request.setAttribute("username", username);
                request.setAttribute("name", name);
                request.setAttribute("surname", surname);
                request.setAttribute("phone", phone);

                rs.close();
                showClient.close();
                con.close();

                if (found) {
                    Connection con1 = datasource.getConnection();

                    PreparedStatement showPrograms = con1.prepareStatement(((Seller) LoginServlet.user).showPrograms());
                    ResultSet rs1 = showPrograms.executeQuery();

                    int i = 0;
                    String htmlRow = "";
                    while (rs1.next()) {
                        i++;

                        String pr_name = rs1.getString("program_name");
                        int fixed_charge = rs1.getInt("fixed_charge");
                        double minutes_charge = rs1.getDouble("minutes_charge");
                        double messages_charge = rs1.getDouble("messages_charge");
                        int minutes = rs1.getInt("minutes");
                        int messages = rs1.getInt("messages");
                        htmlRow = createHTMLRow(pr_name, fixed_charge, minutes_charge, messages_charge, minutes, messages);
                        request.setAttribute("htmlrow" + i, htmlRow);
                        request.setAttribute("pr_name" + i, pr_name);

                    }

                    request.setAttribute("numberofrows", i);

                    rs1.close();
                    showPrograms.close();
                    con1.close();
                }

                request.setAttribute("found", found);
                request.getRequestDispatcher("/cust_program.jsp").forward(request, response);

            } catch (Exception e) {
                out.println("Database connection problem");
//            out.println("<br>");
//            out.println(e.getLocalizedMessage());
            }
        }
        else
            out.println("Session Timeout!");
    }
}
