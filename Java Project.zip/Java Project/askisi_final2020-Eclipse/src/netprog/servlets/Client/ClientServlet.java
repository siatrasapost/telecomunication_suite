package netprog.servlets.Client;

import netprog.classes.users.Client;
import netprog.classes.users.Seller;
import netprog.servlets.Encryption;
import netprog.servlets.LoginServlet;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/clientservlet")
public class ClientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static Client client = new Client("", "");

    private DataSource datasource = null;

    /**
     * Establishes the Datasource required for the servlet
     * @throws ServletException
     */
    public void init() throws ServletException{
        try {

            InitialContext ctx = new InitialContext();
            datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/LiveDataSource");
        } catch(Exception e) {
            throw new ServletException(e.toString());
        }
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Παράδειγμα Servlet με Βάση</title></head>");
        out.println("<body>");

        if(LoginServlet.session!=null) {
            try {
                Connection con = datasource.getConnection();

                PreparedStatement clientinfo = con.prepareStatement(((Client) LoginServlet.user).viewPersonalData());
                clientinfo.setString(1, ((Client)LoginServlet.user).getUsername());
                ResultSet rs = clientinfo.executeQuery();
                int i = 0;
                String username = "";
                String name = "";
                String surname = "";
                String tin = "";
                String phone = "";

                while (rs.next()) {
                    i++;

                    username = rs.getString("username");
                    name = rs.getString("name");
                    surname = rs.getString("surname");
                    tin = rs.getString("tin");
                    phone = rs.getString("phone_number");

                    request.setAttribute("username", username);
                    request.setAttribute("name", name);
                    request.setAttribute("surname", surname);
                    request.setAttribute("tin", tin);
                    request.setAttribute("phone", phone);

                }
//                request.setAttribute("session_info", ((Seller)LoginServlet.session.getAttribute("seller")).getName() + " "
//                        + ((Seller)LoginServlet.session.getAttribute("seller")).getSurname());
                request.getRequestDispatcher("/client_info.jsp").forward(request, response);

                clientinfo.close();
                rs.close();

                con.close();
            } catch (Exception e) {
                out.println("Database connection problem");
                out.println("<br>");
                out.println(e.getLocalizedMessage());
            }
        }
        else {
            out.println("Session Timeout");
        }
    }

    public static Client getClient(String name, String surname, String username, String number){
        client.setName(name);
        client.setSurname(surname);
        client.setUsername(username);
        client.number = number;
        return client;
    }
}
